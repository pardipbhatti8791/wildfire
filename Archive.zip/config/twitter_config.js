var Twitter = require('twitter');
 
var client = new Twitter({
  consumer_key: 'ndsBuf49ldytl7Vbkr8cYKahq',
  consumer_secret: '46L0RpbiUuxBEM3h3HkZC3AKnq153QCINreSsmvaLNAPZUzC5E',
  access_token_key: '998758227604131841-0AjNHWAMV6iTzfUcnOATkWbApIInJLk',
  access_token_secret: 'MBApvGQfahrVnn2MFkPfkbUP4XTP0zWv3Ffkg8gATUKwR'
});

module.exports = client;