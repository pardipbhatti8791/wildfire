var sampleCoordinates = [
    {lat: -33.890542, lng: 151.274856},
    {lat: -33.923036, lng: 151.259052},
    {lat: -34.028249, lng: 151.157507},
    {lat: -33.80010128657071, lng: 151.28747820854187},
    {lat: -33.950198, lng: 151.259302}
  ];

var myLatLng = {lat: -33.90, lng: 151.16};  

exports.sample = sampleCoordinates;
exports.sampleMain = myLatLng